{
  for (int c0 = 1; c0 <= N; c0 += 1)
    S1(c0);
  for (int c0 = N + 1; c0 <= 2 * N; c0 += 1)
    S2(c0);
}
