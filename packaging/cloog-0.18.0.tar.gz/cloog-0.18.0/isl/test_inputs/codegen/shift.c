for (int c0 = 0; c0 <= 9; c0 += 1) {
  A(c0);
  B(c0);
}
