#include <clang/AST/Decl.h>

bool has_annotation(clang::Decl *decl, const char *name);
