#include <isl/stream.h>

struct isl_token *isl_token_new(isl_ctx *ctx,
	int line, int col, unsigned on_new_line);
