for (int c0 = 1; c0 <= n; c0 += 1) {
  S1(c0);
  for (int c1 = 1; c1 <= m; c1 += 1)
    S2(c0, c1);
}
