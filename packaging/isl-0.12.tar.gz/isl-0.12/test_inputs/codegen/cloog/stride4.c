if (t >= 0 && t <= 15)
  for (int c0 = t; c0 <= 99; c0 += 16)
    S1(c0, t);
